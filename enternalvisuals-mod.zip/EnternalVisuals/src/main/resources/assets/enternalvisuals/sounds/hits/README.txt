Сюда кидай звуки ударов (uwu.ogg, meow.ogg, ahh.ogg)
