Сюда кидай: menu_background.png, logo.png
