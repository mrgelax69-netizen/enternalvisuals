package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

public class Cooldowns {

    public static void register() {
        HudRenderCallback.EVENT.register(Cooldowns::render);
    }

    private static void render(MatrixStack matrices, float tickDelta) {
        if (!isEnabled() || MinecraftClient.getInstance().player == null) return;

        MinecraftClient client = MinecraftClient.getInstance();
        ItemStack stack = client.player.getMainHandStack();
        if (stack.isEmpty()) return;

        float cooldown = client.player.getItemCooldownManager().getCooldownProgress(stack.getItem(), tickDelta);
        if (cooldown <= 0f) return; // предмет готов — ничего не рисуем

        int x = client.getWindow().getScaledWidth() / 2 - 20;
        int y = client.getWindow().getScaledHeight() / 2 + 20;

        String text = String.format("%.1fs", cooldown * 20f / 20f); // приблизительная оценка в секундах
        client.textRenderer.drawWithShadow(matrices, text, x, y, 0xFF5555);
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.HUD).stream()
                .anyMatch(t -> t.name.equals("Cooldowns") && t.enabled);
    }
}
