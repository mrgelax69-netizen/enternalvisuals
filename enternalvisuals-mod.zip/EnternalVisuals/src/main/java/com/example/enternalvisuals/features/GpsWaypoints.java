package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class GpsWaypoints {

    public static class Waypoint {
        public final String name;
        public final BlockPos pos;
        public Waypoint(String name, BlockPos pos) { this.name = name; this.pos = pos; }
    }

    private static final List<Waypoint> WAYPOINTS = new ArrayList<>();

    public static void add(String name, BlockPos pos) {
        WAYPOINTS.add(new Waypoint(name, pos));
    }

    public static void remove(String name) {
        WAYPOINTS.removeIf(w -> w.name.equalsIgnoreCase(name));
    }

    public static List<Waypoint> all() {
        return WAYPOINTS;
    }

    public static void register() {
        HudRenderCallback.EVENT.register(GpsWaypoints::render);
    }

    private static void render(MatrixStack matrices, float tickDelta) {
        if (!isEnabled() || WAYPOINTS.isEmpty()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        int x = 4;
        int y = 30;
        BlockPos playerPos = client.player.getBlockPos();

        for (Waypoint w : WAYPOINTS) {
            double dist = Math.sqrt(playerPos.getSquaredDistance(w.pos));
            String text = w.name + " - " + (int) dist + "m";
            client.textRenderer.drawWithShadow(matrices, text, x, y, 0x55CCFF);
            y += 10;
        }
    }

    private static boolean isEnabled() {
        // GPS считаем частью Utility — используем существующий переключатель "Auto Sethome" пока нет отдельного тумблера GPS
        return true; // метки всегда показываются, если добавлены (можно позже привязать к своему toggle)
    }
}
