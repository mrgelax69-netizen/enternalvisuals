package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class TargetHud {

    public static void register() {
        HudRenderCallback.EVENT.register(TargetHud::render);
    }

    private static void render(MatrixStack matrices, float tickDelta) {
        if (!isEnabled()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        // Берём то, на что игрок реально смотрит (crosshairTarget уже учитывает прямую видимость,
        // блоки и стены естественно перекрывают луч — просвечивания сквозь стены тут нет)
        HitResult hit = client.crosshairTarget;
        if (!(hit instanceof EntityHitResult)) return;

        EntityHitResult entityHit = (EntityHitResult) hit;
        if (!(entityHit.getEntity() instanceof LivingEntity)) return;

        LivingEntity target = (LivingEntity) entityHit.getEntity();

        int x = client.getWindow().getScaledWidth() / 2 - 60;
        int y = 30;

        String name = target.getName().getString();
        String health = String.format("HP: %.1f / %.1f", target.getHealth(), target.getMaxHealth());

        client.textRenderer.drawWithShadow(matrices, name, x, y, 0xFFFFFF);
        client.textRenderer.drawWithShadow(matrices, health, x, y + 10, 0xFF5555);

        if (target instanceof PlayerEntity) {
            PlayerEntity playerTarget = (PlayerEntity) target;
            String heldItem = playerTarget.getMainHandStack().isEmpty()
                    ? "пусто" : playerTarget.getMainHandStack().getName().getString();
            client.textRenderer.drawWithShadow(matrices, "В руке: " + heldItem, x, y + 20, 0xCCCCCC);
        }
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.HUD).stream()
                .anyMatch(t -> t.name.equals("Target HUD") && t.enabled);
    }
}
