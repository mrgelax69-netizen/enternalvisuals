package com.example.enternalvisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import com.example.enternalvisuals.gui.EnternalVisualsScreen;
import com.example.enternalvisuals.hud.Watermark;
import com.example.enternalvisuals.features.AutoSprint;
import com.example.enternalvisuals.features.StreamerMode;
import com.example.enternalvisuals.features.ArmorHud;
import com.example.enternalvisuals.features.PotionsHud;
import com.example.enternalvisuals.features.GpsWaypoints;
import com.example.enternalvisuals.features.Friends;
import com.example.enternalvisuals.features.AutoTpAccept;
import com.example.enternalvisuals.features.Pinger;
import com.example.enternalvisuals.features.Particles;
import com.example.enternalvisuals.features.HitSounds;
import com.example.enternalvisuals.features.Trails;
import com.example.enternalvisuals.features.Cooldowns;
import com.example.enternalvisuals.features.TargetHud;
import com.example.enternalvisuals.features.ShiftTab;
import com.example.enternalvisuals.features.Optimizator;
import com.example.enternalvisuals.features.BlockOverlay;

public class EnternalVisualsClient implements ClientModInitializer {

    // Клавиша, которая открывает меню — правый шифт
    public static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {

        // Регистрируем клавишу
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.enternalvisuals.openmenu",          // название клавиши (для F3+T / настроек)
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,           // сам правый шифт
                "category.enternalvisuals.main"           // категория в настройках управления
        ));

        // Каждый тик игры проверяем, нажата ли клавиша
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new EnternalVisualsScreen());
                }
            }
        });

        // Регистрируем отрисовку ХАДа (ватермарк)
        Watermark.register();

        // Новые рабочие фичи
        AutoSprint.register();
        StreamerMode.register();
        ArmorHud.register();
        PotionsHud.register();
        GpsWaypoints.register();
        Friends.register();
        AutoTpAccept.register();
        Pinger.register();
        Particles.register();
        HitSounds.register();
        Trails.register();
        Cooldowns.register();
        TargetHud.register();
        ShiftTab.register();
        Optimizator.register();
        BlockOverlay.register();
    }
}
