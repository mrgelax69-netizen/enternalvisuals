package com.example.enternalvisuals.gui;

import com.example.enternalvisuals.config.ModConfig;
import com.example.enternalvisuals.config.ModConfig.Tab;
import com.example.enternalvisuals.config.Toggle;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.List;

public class EnternalVisualsScreen extends Screen {

    // Путь к нарисованной тобой текстуре
    private static final Identifier BACKGROUND =
            new Identifier("enternalvisuals", "textures/gui/menu_background.png");

    // Размер самой панели на экране (можно потом подвинуть под свой рисунок)
    private static final int PANEL_W = 256;
    private static final int PANEL_H = 256;

    private int panelX, panelY;
    private Tab currentTab = Tab.VISUALS;

    // Область, где рисуется прокручиваемый список функций
    private static final int LIST_TOP_OFFSET = 100;   // отступ списка от верха панели
    private static final int LIST_BOTTOM_OFFSET = 20;  // отступ списка от низа панели
    private static final int ROW_HEIGHT = 18;

    private double scrollOffset = 0;

    public EnternalVisualsScreen() {
        super(new LiteralText("EnternalVisuals"));
    }

    @Override
    protected void init() {
        super.init();
        panelX = (width - PANEL_W) / 2;
        panelY = (height - PANEL_H) / 2;
        scrollOffset = 0;
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        renderBackground(matrices);

        // Рисуем твою текстуру
        client.getTextureManager().bindTexture(BACKGROUND);
        drawTexture(matrices, panelX, panelY, 0, 0, PANEL_W, PANEL_H, PANEL_W, PANEL_H);

        // Вкладки (текстовые кликабельные зоны сверху панели)
        renderTabs(matrices, mouseX, mouseY);

        // Список функций с прокруткой
        renderToggleList(matrices, mouseX, mouseY);

        super.render(matrices, mouseX, mouseY, delta);
    }

    private void renderTabs(MatrixStack matrices, int mouseX, int mouseY) {
        int tabY = panelY + 62;
        String[] names = {"VISUALS", "HUD", "UTILITY"};
        Tab[] tabs = {Tab.VISUALS, Tab.HUD, Tab.UTILITY};

        int totalWidth = 0;
        for (String n : names) totalWidth += textRenderer.getWidth(n) + 16;
        int x = panelX + (PANEL_W - totalWidth) / 2;

        for (int i = 0; i < names.length; i++) {
            int w = textRenderer.getWidth(names[i]);
            boolean active = tabs[i] == currentTab;
            int color = active ? 0xFFFFFF : 0xAAAAAA;
            drawCenteredText(matrices, textRenderer, names[i], x + w / 2, tabY, color);
            x += w + 16;
        }
    }

    private void renderToggleList(MatrixStack matrices, int mouseX, int mouseY) {
        List<Toggle> toggles = ModConfig.get(currentTab);

        int listX = panelX + 20;
        int listWidth = PANEL_W - 40;
        int listTop = panelY + LIST_TOP_OFFSET;
        int listBottom = panelY + PANEL_H - LIST_BOTTOM_OFFSET;

        // Обрезаем отрисовку по границам списка, чтобы кнопки не вылезали за панель
        enableScissor(listX, listTop, listX + listWidth, listBottom);

        int y = (int) (listTop - scrollOffset);
        for (Toggle toggle : toggles) {
            if (y + ROW_HEIGHT >= listTop && y <= listBottom) {
                boolean hovered = mouseX >= listX && mouseX <= listX + listWidth
                        && mouseY >= y && mouseY <= y + ROW_HEIGHT;

                int bg = hovered ? 0x40FFFFFF : 0x20000000;
                fill(matrices, listX, y, listX + listWidth, y + ROW_HEIGHT - 2, bg);

                drawTextWithShadow(matrices, textRenderer, toggle.name, listX + 6, y + 5, 0xFFFFFF);

                String state = toggle.enabled ? "ON" : "OFF";
                int stateColor = toggle.enabled ? 0x55FF55 : 0xFF5555;
                int stateW = textRenderer.getWidth(state);
                drawTextWithShadow(matrices, textRenderer, state,
                        listX + listWidth - stateW - 6, y + 5, stateColor);
            }
            y += ROW_HEIGHT;
        }

        disableScissor();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Клик по вкладкам
        int tabY = panelY + 56;
        String[] names = {"VISUALS", "HUD", "UTILITY"};
        Tab[] tabs = {Tab.VISUALS, Tab.HUD, Tab.UTILITY};
        int totalWidth = 0;
        for (String n : names) totalWidth += textRenderer.getWidth(n) + 16;
        int x = panelX + (PANEL_W - totalWidth) / 2;

        for (int i = 0; i < names.length; i++) {
            int w = textRenderer.getWidth(names[i]);
            if (mouseX >= x && mouseX <= x + w && mouseY >= tabY && mouseY <= tabY + 10) {
                currentTab = tabs[i];
                scrollOffset = 0;
                return true;
            }
            x += w + 16;
        }

        // Клик по списку функций
        List<Toggle> toggles = ModConfig.get(currentTab);
        int listX = panelX + 20;
        int listWidth = PANEL_W - 40;
        int listTop = panelY + LIST_TOP_OFFSET;

        int y = (int) (listTop - scrollOffset);
        for (Toggle toggle : toggles) {
            if (mouseX >= listX && mouseX <= listX + listWidth
                    && mouseY >= y && mouseY <= y + ROW_HEIGHT - 2) {
                toggle.enabled = !toggle.enabled; // переключаем функцию
                return true;
            }
            y += ROW_HEIGHT;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        List<Toggle> toggles = ModConfig.get(currentTab);
        int visibleHeight = PANEL_H - LIST_TOP_OFFSET - LIST_BOTTOM_OFFSET;
        int contentHeight = toggles.size() * ROW_HEIGHT;
        double maxScroll = Math.max(0, contentHeight - visibleHeight);

        scrollOffset = MathHelper.clamp(scrollOffset - amount * ROW_HEIGHT, 0, maxScroll);
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
