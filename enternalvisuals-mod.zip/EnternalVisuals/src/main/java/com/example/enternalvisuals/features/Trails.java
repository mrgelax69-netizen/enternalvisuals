package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;

public class Trails {

    private static int tickCounter = 0;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(Trails::tick);
    }

    private static void tick(MinecraftClient client) {
        if (!isEnabled() || client.player == null || client.world == null) return;

        // "Пунктир" — ставим частицу не каждый тик, а через раз, чтобы был разрыв между точками
        tickCounter++;
        if (tickCounter % 2 != 0) return;

        double x = client.player.getX();
        double y = client.player.getY() + 0.1;
        double z = client.player.getZ();

        client.world.addParticle(ParticleTypes.CRIT, x, y, z, 0, 0, 0);
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.VISUALS).stream()
                .anyMatch(t -> t.name.equals("Trails") && t.enabled);
    }
}
