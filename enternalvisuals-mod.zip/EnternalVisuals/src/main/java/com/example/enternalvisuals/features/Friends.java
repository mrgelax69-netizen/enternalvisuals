package com.example.enternalvisuals.features;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.LiteralText;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Friends {

    private static final Set<String> FRIEND_NAMES = new HashSet<>();
    private static final Set<String> ONLINE_LAST_TICK = new HashSet<>();
    private static int tickCounter = 0;

    public static void add(String name) {
        FRIEND_NAMES.add(name.toLowerCase());
    }

    public static void remove(String name) {
        FRIEND_NAMES.remove(name.toLowerCase());
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(Friends::tick);
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.getNetworkHandler() == null) return;
        if (FRIEND_NAMES.isEmpty()) return;

        // Проверяем табличку игроков раз в секунду (каждые 20 тиков), чтобы не грузить процессор
        tickCounter++;
        if (tickCounter < 20) return;
        tickCounter = 0;

        List<String> onlineNow = client.getNetworkHandler().getPlayerList().stream()
                .map(PlayerListEntry::getProfile)
                .map(p -> p.getName().toLowerCase())
                .filter(FRIEND_NAMES::contains)
                .collect(Collectors.toList());

        // Кто зашёл
        for (String name : onlineNow) {
            if (!ONLINE_LAST_TICK.contains(name)) {
                client.player.sendMessage(new LiteralText("§b[Friends] §a" + name + " зашёл в игру"), false);
            }
        }
        // Кто вышел
        for (String name : ONLINE_LAST_TICK) {
            if (!onlineNow.contains(name)) {
                client.player.sendMessage(new LiteralText("§b[Friends] §c" + name + " вышел из игры"), false);
            }
        }

        ONLINE_LAST_TICK.clear();
        ONLINE_LAST_TICK.addAll(onlineNow);
    }
}
