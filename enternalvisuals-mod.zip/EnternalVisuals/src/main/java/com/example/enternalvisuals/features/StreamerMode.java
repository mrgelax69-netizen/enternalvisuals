package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StreamerMode {

    // Ловим отдельно стоящие числа от 1 до 9999 (например номер режима в скорборде/табе)
    private static final Pattern NUMBER_PATTERN = Pattern.compile("\\b([1-9][0-9]{0,3})\\b");

    public static void register() {
        // Фильтруем входящие сообщения чата
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (!isEnabled()) return true;
            return true; // сообщения не блокируем, только маскируем ник ниже в HUD-рендере
        });
    }

    public static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.UTILITY).stream()
                .anyMatch(t -> t.name.equals("Streamer Mode") && t.enabled);
    }

    // Вызывается из виджетов таба/скорборда перед отрисовкой текста
    public static String mask(String original) {
        if (!isEnabled()) return original;

        MinecraftClient client = MinecraftClient.getInstance();
        String result = original;

        // Прячем собственный ник
        if (client.player != null) {
            result = result.replace(client.player.getGameProfile().getName(), "СЕКРЕТ");
        }

        // Заменяем голые числа 1-9999 (типичный "номер режима" в скорборде/табе)
        Matcher matcher = NUMBER_PATTERN.matcher(result);
        result = matcher.replaceAll("СЕКРЕТ");

        return result;
    }
}
