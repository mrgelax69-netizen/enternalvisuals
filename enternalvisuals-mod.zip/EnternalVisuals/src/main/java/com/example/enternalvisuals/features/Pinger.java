package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.text.LiteralText;

import java.util.HashSet;
import java.util.Set;

public class Pinger {

    private static final int WARN_PERCENT = 20; // предупреждаем когда прочность ниже 20%
    private static final Set<String> ALREADY_WARNED = new HashSet<>();

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(Pinger::tick);
    }

    private static void tick(MinecraftClient client) {
        if (!isEnabled() || client.player == null) return;

        for (ItemStack stack : client.player.getArmorItems()) {
            if (stack.isEmpty() || stack.getMaxDamage() == 0) continue;

            int percent = 100 - (stack.getDamage() * 100 / stack.getMaxDamage());
            String key = stack.getItem().toString();

            if (percent <= WARN_PERCENT && !ALREADY_WARNED.contains(key)) {
                client.player.sendMessage(new LiteralText(
                        "§c[Pinger] " + stack.getName().getString() + " почти сломан (" + percent + "%)"), false);
                ALREADY_WARNED.add(key);
            } else if (percent > WARN_PERCENT) {
                ALREADY_WARNED.remove(key); // предмет починили/сменили — снова можно предупреждать
            }
        }
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.UTILITY).stream()
                .anyMatch(t -> t.name.equals("Pinger") && t.enabled);
    }
}
