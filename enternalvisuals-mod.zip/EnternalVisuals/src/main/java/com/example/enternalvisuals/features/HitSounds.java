package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.ActionResult;
import net.minecraft.util.registry.Registry;

public class HitSounds {

    // Звуковые файлы нужно положить в assets/enternalvisuals/sounds/hits/ (uwu.ogg, meow.ogg, ahh.ogg)
    // и прописать в sounds.json — без этого файла звук не подключится, сделаем его следующим шагом
    private static String selectedSound = "uwu";

    public static void setSound(String name) {
        selectedSound = name;
    }

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!isEnabled()) return ActionResult.PASS;

            MinecraftClient client = MinecraftClient.getInstance();
            Identifier soundId = new Identifier("enternalvisuals", "hit_" + selectedSound);
            SoundEvent sound = Registry.SOUND_EVENT.get(soundId);

            if (sound != null && client.player != null) {
                client.player.playSound(sound, 1.0f, 1.0f);
            }
            return ActionResult.PASS; // не мешаем ванильному удару
        });
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.VISUALS).stream()
                .anyMatch(t -> t.name.equals("Hit Sounds") && t.enabled);
    }
}
