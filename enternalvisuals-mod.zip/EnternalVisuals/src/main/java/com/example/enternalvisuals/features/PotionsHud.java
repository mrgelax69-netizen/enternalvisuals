package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffectInstance;

public class PotionsHud {

    public static void register() {
        HudRenderCallback.EVENT.register(PotionsHud::render);
    }

    private static void render(MatrixStack matrices, float tickDelta) {
        if (!isEnabled()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        int x = 4;
        int y = client.getWindow().getScaledHeight() - 20;

        int i = 0;
        for (StatusEffectInstance effect : client.player.getStatusEffects()) {
            String name = effect.getEffectType().getName().getString();
            int seconds = effect.getDuration() / 20;
            String time = (seconds / 60) + ":" + String.format("%02d", seconds % 60);

            client.textRenderer.drawWithShadow(matrices,
                    name + " " + (effect.getAmplifier() + 1) + " (" + time + ")",
                    x, y - i * 10, 0xFFFFFF);
            i++;
        }
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.HUD).stream()
                .anyMatch(t -> t.name.equals("Potions") && t.enabled);
    }
}
