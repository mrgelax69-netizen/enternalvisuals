package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public class AutoSprint {

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoSprint::tick);
    }

    private static void tick(MinecraftClient client) {
        if (!isEnabled()) return;

        ClientPlayerEntity player = client.player;
        if (player == null) return;

        boolean movingForward = client.options.keyForward.isPressed();
        boolean hasHunger = player.getHungerManager().getFoodLevel() > 6;

        if (movingForward && hasHunger && !player.isSprinting() && !player.horizontalCollision) {
            player.setSprinting(true);
        }
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.UTILITY).stream()
                .anyMatch(t -> t.name.equals("Auto Sprint") && t.enabled);
    }
}
