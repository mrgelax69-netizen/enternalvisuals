package com.example.enternalvisuals.mixin;

import com.example.enternalvisuals.config.ModConfig;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class NoFluidMixin {

    // Ванильный метод рисует оверлей (лава/вода/огонь) по текстуре. Если это лава и функция включена — отменяем отрисовку.
    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true)
    private void enternalvisuals$cancelLavaOverlay(Identifier texture, float opacity, CallbackInfo ci) {
        if (isEnabled() && texture.getPath().contains("lava")) {
            ci.cancel();
        }
    }

    private boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.VISUALS).stream()
                .anyMatch(t -> t.name.equals("No Fluid") && t.enabled);
    }
}
