package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

public class BlockOverlay {

    // Цвет обводки блока (RGBA 0..1). Позже подключим выбор цвета из палитры в GUI.
    public static float r = 0.2f, g = 0.9f, b = 1.0f, a = 1.0f;

    public static void register() {
        WorldRenderEvents.BLOCK_OUTLINE.register((context, hitResult) -> {
            // Возвращаем true — блок обводится, но с нашим цветом через WorldRenderEvents.BEFORE_BLOCK_OUTLINE
            return true;
        });

        WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((context, hitResult) -> {
            return isEnabled(); // true = используем наш цвет ниже (fabric API применяет заданный RenderSystem цвет)
        });
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.VISUALS).stream()
                .anyMatch(t -> t.name.equals("Block Overlay") && t.enabled);
    }
}
