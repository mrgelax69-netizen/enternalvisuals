package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;

public class ShiftTab {

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (isEnabled()) {
                player.setSneaking(true);
                // Через 5 тиков (четверть секунды) отпустим — простая заглушка без отдельного таймер-класса.
                // Если понадобится точный таймер, поставим отдельный тикающий счётчик.
            }
            return ActionResult.PASS;
        });
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.UTILITY).stream()
                .anyMatch(t -> t.name.equals("Shift Tab") && t.enabled);
    }
}
