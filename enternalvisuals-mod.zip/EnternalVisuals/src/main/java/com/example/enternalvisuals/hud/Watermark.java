package com.example.enternalvisuals.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.network.PlayerListEntry;

public class Watermark {

    public static void register() {
        HudRenderCallback.EVENT.register(Watermark::render);
    }

    private static void render(MatrixStack matrices, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.debugEnabled) return; // не рисуем поверх F3

        int fps = client.getCurrentFps();
        int ping = getPing(client);

        String text = "EnternalVisuals | FPS: " + fps + " | Ping: " + ping;

        client.textRenderer.drawWithShadow(matrices, text, 4, 4, 0xFFFFFF);
    }

    private static int getPing(MinecraftClient client) {
        if (client.getNetworkHandler() == null || client.player == null) return 0;
        PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        return entry != null ? entry.getLatency() : 0;
    }
}
