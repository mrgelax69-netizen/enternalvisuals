package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

public class ArmorHud {

    public static void register() {
        HudRenderCallback.EVENT.register(ArmorHud::render);
    }

    private static void render(MatrixStack matrices, float tickDelta) {
        if (!isEnabled()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        int x = client.getWindow().getScaledWidth() - 70;
        int y = 4;

        // Порядок: шлем, нагрудник, штаны, ботинки (индексы 3..0 в getArmorItems)
        Iterable<ItemStack> armorItems = client.player.getArmorItems();
        int i = 0;
        for (ItemStack stack : armorItems) {
            if (!stack.isEmpty()) {
                int maxDamage = stack.getMaxDamage();
                int damage = stack.getDamage();
                int durabilityLeft = maxDamage - damage;
                int percent = maxDamage > 0 ? (durabilityLeft * 100 / maxDamage) : 100;

                int color = percent > 50 ? 0x55FF55 : (percent > 20 ? 0xFFAA00 : 0xFF5555);

                client.textRenderer.drawWithShadow(matrices,
                        stack.getName().getString() + ": " + percent + "%",
                        x, y + i * 10, color);
            }
            i++;
        }
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.HUD).stream()
                .anyMatch(t -> t.name.equals("Armor HUD") && t.enabled);
    }
}
