package com.example.enternalvisuals.config;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class ModConfig {

    public enum Tab { VISUALS, HUD, UTILITY }

    // На каждую вкладку — свой список функций (порядок = порядок появления в списке)
    private static final Map<Tab, List<Toggle>> TOGGLES = new LinkedHashMap<>();

    static {
        List<Toggle> visuals = new ArrayList<>();
        visuals.add(new Toggle("Particles", false));
        visuals.add(new Toggle("Custom World", false));
        visuals.add(new Toggle("Crosshair", false));
        visuals.add(new Toggle("Trails", false));
        visuals.add(new Toggle("Hit Color", false));
        visuals.add(new Toggle("Scroll", false));
        visuals.add(new Toggle("Target ESP", false)); // подсветка только видимой цели, без просвечивания стен
        visuals.add(new Toggle("Animations", false));
        visuals.add(new Toggle("Hit Sounds", false));
        visuals.add(new Toggle("No Fluid", false));
        visuals.add(new Toggle("Name Tag", false));
        visuals.add(new Toggle("Logo Name", false));
        visuals.add(new Toggle("No Lag", false));
        visuals.add(new Toggle("Block Overlay", false));
        visuals.add(new Toggle("Effect Kill", false));
        TOGGLES.put(Tab.VISUALS, visuals);

        List<Toggle> hud = new ArrayList<>();
        hud.add(new Toggle("Watermark", true));
        hud.add(new Toggle("Target HUD", false));
        hud.add(new Toggle("Potions", false));
        hud.add(new Toggle("Inventory", false));
        hud.add(new Toggle("Cooldowns", false));
        hud.add(new Toggle("Armor HUD", false));
        TOGGLES.put(Tab.HUD, hud);

        List<Toggle> utility = new ArrayList<>();
        utility.add(new Toggle("Auto TP Accept", false));
        utility.add(new Toggle("Streamer Mode", false));
        utility.add(new Toggle("Check Shulker", false));
        utility.add(new Toggle("Shift Tab", false));
        utility.add(new Toggle("Pinger", false));
        utility.add(new Toggle("Auto Sprint", false));
        utility.add(new Toggle("Auto Sethome", false));
        utility.add(new Toggle("Auto Leave", false));
        utility.add(new Toggle("Auto Duel", false));
        utility.add(new Toggle("Optimizator", false));
        utility.add(new Toggle("Bow Optimizer", false));
        TOGGLES.put(Tab.UTILITY, utility);
    }

    public static List<Toggle> get(Tab tab) {
        return TOGGLES.get(tab);
    }
}
