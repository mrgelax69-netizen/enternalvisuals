package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.options.ParticlesOption;

public class Optimizator {

    private static boolean appliedOnce = false;
    private static boolean wasEnabled = false;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(Optimizator::tick);
    }

    private static void tick(MinecraftClient client) {
        boolean enabled = isEnabled();
        if (enabled == wasEnabled) return; // применяем настройки только при смене состояния
        wasEnabled = enabled;

        if (enabled) {
            client.options.particles = ParticlesOption.MINIMAL;
            client.options.viewDistance = Math.min(client.options.viewDistance, 8);
            client.options.entityShadows = false;
            client.options.fancyGraphics = false;
        } else {
            // Возвращаем разумные значения по умолчанию (не идеально помним прошлые, но безопасно)
            client.options.particles = ParticlesOption.ALL;
            client.options.entityShadows = true;
            client.options.fancyGraphics = true;
        }
        client.options.write();
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.UTILITY).stream()
                .anyMatch(t -> t.name.equals("Optimizator") && t.enabled);
    }
}
