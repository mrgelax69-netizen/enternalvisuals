package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;

public class Particles {

    // Пока один тип частиц (сфера вокруг игрока). Кубы/звёзды/метеоры и цвета — следующим шагом,
    // когда решим что рисовать своими текстурами частиц (ванильные типы не поддерживают произвольный цвет напрямую).
    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(Particles::tick);
    }

    private static void tick(MinecraftClient client) {
        if (!isEnabled() || client.player == null || client.world == null) return;

        ClientWorld world = client.world;
        double x = client.player.getX();
        double y = client.player.getY() + 1.0;
        double z = client.player.getZ();

        double radius = 0.8;
        double angle = (System.currentTimeMillis() % 3600) / 3600.0 * Math.PI * 2;

        double px = x + Math.cos(angle) * radius;
        double pz = z + Math.sin(angle) * radius;

        world.addParticle(ParticleTypes.END_ROD, px, y, pz, 0, 0, 0);
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.VISUALS).stream()
                .anyMatch(t -> t.name.equals("Particles") && t.enabled);
    }
}
