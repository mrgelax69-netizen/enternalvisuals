package com.example.enternalvisuals.features;

import com.example.enternalvisuals.config.ModConfig;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;

import java.util.regex.Pattern;

public class AutoTpAccept {

    // Общий паттерн под большинство серверов: "... has requested to teleport ..." / "... хочет телепортироваться ..."
    // Подстрой под свой сервер, если формат другой
    private static final Pattern REQUEST_PATTERN = Pattern.compile(
            "(?i)(has requested to teleport|хочет телепортироваться|запросил телепорт)");

    public static void register() {
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (isEnabled() && REQUEST_PATTERN.matcher(message.getString()).find()) {
                MinecraftClient client = MinecraftClient.getInstance();
                if (client.getNetworkHandler() != null) {
                    client.getNetworkHandler().sendChatCommand("tpaccept");
                }
            }
            return true; // сообщение всё равно показываем в чате
        });
    }

    private static boolean isEnabled() {
        return ModConfig.get(ModConfig.Tab.UTILITY).stream()
                .anyMatch(t -> t.name.equals("Auto TP Accept") && t.enabled);
    }
}
